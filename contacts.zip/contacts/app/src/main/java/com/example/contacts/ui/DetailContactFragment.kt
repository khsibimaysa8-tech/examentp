package com.example.contacts.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.TypedValue
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import com.example.contacts.R
import com.example.contacts.data.Contact
import com.example.contacts.data.PreferencesManager
import kotlinx.coroutines.launch
import java.io.File
import android.provider.OpenableColumns
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import java.io.FileOutputStream

class DetailContactFragment : Fragment(R.layout.fragment_detail_contact) {

    private val viewModel: ContactViewModel by activityViewModels()

    // 0 = mode création
    private var contactId: Long = 0L

    // Valeurs non affichées dans un champ texte, conservées pour l'enregistrement
    private var photoPath: String? = null

    private lateinit var imgPhoto: ImageView
    private lateinit var editNom: EditText
    private lateinit var editPrenom: EditText
    private lateinit var editTelephone: EditText
    private lateinit var editEmail: EditText
    private lateinit var editLatitude: EditText
    private lateinit var editLongitude: EditText
    // Fichier de la photo prise par la caméra (avant validation)
    private var cameraFile: File? = null

    // Galerie : l'utilisateur choisit une image (null = annulation)
    private val galerieLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri == null) {
                Toast.makeText(requireContext(), "Aucune image choisie", Toast.LENGTH_SHORT).show()
            } else {
                copierVersFilesDir(uri)
            }
        }

    // Caméra : écrit dans cameraFile (success = false si annulé)
    private val cameraLauncher =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
            val f = cameraFile
            if (success && f != null && f.exists() && f.length() > 0) {
                photoPath = f.absolutePath
                afficherPhoto()
            } else {
                f?.delete()
                Toast.makeText(requireContext(), "Photo annulée", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        contactId = arguments?.getLong(ARG_ID, 0L) ?: 0L
        photoPath = savedInstanceState?.getString(KEY_PHOTO)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        imgPhoto = view.findViewById(R.id.imgPhoto)
        editNom = view.findViewById(R.id.editNom)
        editPrenom = view.findViewById(R.id.editPrenom)
        editTelephone = view.findViewById(R.id.editTelephone)
        editEmail = view.findViewById(R.id.editEmail)
        editLatitude = view.findViewById(R.id.editLatitude)
        editLongitude = view.findViewById(R.id.editLongitude)

        val btnSupprimer = view.findViewById<Button>(R.id.btnSupprimer)

        appliquerPrefs()

        // Création : champs vides, pas de bouton Supprimer
        if (contactId == 0L) {
            btnSupprimer.visibility = View.GONE
        } else if (savedInstanceState == null) {
            // Read : chargement depuis la base (seulement au 1er affichage,
            // pour ne pas écraser la saisie après une rotation)
            chargerContact()
        } else {
            afficherPhoto()
        }

        view.findViewById<Button>(R.id.btnEnregistrer).setOnClickListener { enregistrer() }
        btnSupprimer.setOnClickListener { confirmerSuppression() }
        view.findViewById<Button>(R.id.btnAppeler).setOnClickListener { appeler() }
        view.findViewById<Button>(R.id.btnEmail).setOnClickListener { envoyerEmail() }
        // btnGalerie, btnCamera, btnCarte : Étapes suivantes
        view.findViewById<Button>(R.id.btnGalerie).setOnClickListener {
            try {
                galerieLauncher.launch("image/*")
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(requireContext(), "Aucune galerie disponible", Toast.LENGTH_SHORT).show()
            }
        }
        view.findViewById<Button>(R.id.btnCamera).setOnClickListener { prendrePhoto() }
        view.findViewById<Button>(R.id.btnCarte).setOnClickListener { ouvrirCarte() }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString(KEY_PHOTO, photoPath)
    }

    // Préférences : taille (nom, prénom, téléphone) + couleur (nom, prénom)
    private fun appliquerPrefs() {
        val p = PreferencesManager.lire(requireContext())
        listOf(editNom, editPrenom, editTelephone).forEach {
            it.setTextSize(TypedValue.COMPLEX_UNIT_SP, p.tailleSp)
        }
        editNom.setTextColor(p.couleur)
        editPrenom.setTextColor(p.couleur)
    }

    private fun chargerContact() {
        viewLifecycleOwner.lifecycleScope.launch {
            val c = viewModel.getContact(contactId)
            if (c == null) {
                Toast.makeText(requireContext(), "Contact introuvable", Toast.LENGTH_SHORT).show()
                parentFragmentManager.popBackStack()
                return@launch
            }
            editNom.setText(c.nom)
            editPrenom.setText(c.prenom)
            editTelephone.setText(c.telephone)
            editEmail.setText(c.email ?: "")
            editLatitude.setText(c.latitude?.toString() ?: "")
            editLongitude.setText(c.longitude?.toString() ?: "")
            photoPath = c.photoUri
            afficherPhoto()
        }
    }

    private fun afficherPhoto() {
        val path = photoPath
        if (path != null && File(path).exists()) {
            imgPhoto.setImageURI(Uri.fromFile(File(path)))
        } else {
            imgPhoto.setImageResource(android.R.drawable.ic_menu_gallery)
        }
    }

    // Create (id = 0) ou Update (id > 0) après validation
    private fun enregistrer() {
        val nom = editNom.text.toString().trim()
        val prenom = editPrenom.text.toString().trim()
        val tel = editTelephone.text.toString().trim()
        val email = editEmail.text.toString().trim()
        val latTexte = editLatitude.text.toString().trim()
        val lonTexte = editLongitude.text.toString().trim()

        var valide = true
        if (nom.isEmpty()) { editNom.error = "Nom obligatoire"; valide = false }
        if (prenom.isEmpty()) { editPrenom.error = "Prénom obligatoire"; valide = false }
        if (tel.isEmpty()) { editTelephone.error = "Téléphone obligatoire"; valide = false }
        if (email.isNotEmpty() &&
            !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
        ) {
            editEmail.error = "E-mail invalide"; valide = false
        }

        // Latitude / longitude : vides = pas de position (null), sinon valides
        val lat = latTexte.toDoubleOrNull()
        val lon = lonTexte.toDoubleOrNull()
        if (latTexte.isNotEmpty() && (lat == null || lat !in -90.0..90.0)) {
            editLatitude.error = "Entre -90 et 90"; valide = false
        }
        if (lonTexte.isNotEmpty() && (lon == null || lon !in -180.0..180.0)) {
            editLongitude.error = "Entre -180 et 180"; valide = false
        }
        if (!valide) return

        val contact = Contact(
            id = contactId,
            nom = nom,
            prenom = prenom,
            telephone = tel,
            email = email.ifEmpty { null },
            photoUri = photoPath,
            latitude = lat,
            longitude = lon
        )

        if (contactId == 0L) viewModel.ajouter(contact) else viewModel.modifier(contact)
        parentFragmentManager.popBackStack()   // retour à la liste
    }

    private fun confirmerSuppression() {
        AlertDialog.Builder(requireContext())
            .setTitle("Supprimer le contact")
            .setMessage("Voulez-vous vraiment supprimer ce contact ?")
            .setPositiveButton("Supprimer") { _, _ ->
                viewModel.supprimer(contactId)
                parentFragmentManager.popBackStack()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun appeler() {
        val tel = editTelephone.text.toString().trim()
        if (tel.isEmpty()) {
            Toast.makeText(requireContext(), "Numéro vide", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(tel))))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(requireContext(), "Aucune application téléphone", Toast.LENGTH_SHORT).show()
        }
    }

    private fun envoyerEmail() {
        val email = editEmail.text.toString().trim()
        if (email.isEmpty()) {
            Toast.makeText(requireContext(), "Aucun e-mail", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$email")))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(requireContext(), "Aucune application e-mail", Toast.LENGTH_SHORT).show()
        }
    }
    // Copie l'image choisie dans filesDir/photos (chemin durable)
    private fun copierVersFilesDir(uri: Uri) {
        try {
            val dossier = File(requireContext().filesDir, "photos").apply { mkdirs() }
            val dest = File(dossier, "photo_${System.currentTimeMillis()}.jpg")
            requireContext().contentResolver.openInputStream(uri)?.use { entree ->
                FileOutputStream(dest).use { sortie -> entree.copyTo(sortie) }
            } ?: throw java.io.IOException("Lecture impossible")
            photoPath = dest.absolutePath
            afficherPhoto()
        } catch (e: Exception) {
            Toast.makeText(requireContext(), "Impossible de copier l'image", Toast.LENGTH_SHORT).show()
        }
    }

    private fun prendrePhoto() {
        try {
            val dossier = File(requireContext().filesDir, "photos").apply { mkdirs() }
            val fichier = File(dossier, "photo_${System.currentTimeMillis()}.jpg")
            cameraFile = fichier
            val uri = FileProvider.getUriForFile(
                requireContext(),
                "${requireContext().packageName}.fileprovider",
                fichier
            )
            cameraLauncher.launch(uri)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(requireContext(), "Aucune application caméra", Toast.LENGTH_SHORT).show()
        }
    }
    private fun ouvrirCarte() {
        val latTxt = editLatitude.text.toString().trim()
        val lngTxt = editLongitude.text.toString().trim()

        if (latTxt.isEmpty() || lngTxt.isEmpty()) {
            Toast.makeText(requireContext(), "Aucune position enregistrée pour ce contact", Toast.LENGTH_LONG).show()
            return
        }
        val lat = latTxt.replace(',', '.').toDoubleOrNull()
        val lng = lngTxt.replace(',', '.').toDoubleOrNull()
        if (lat == null || lng == null) {
            Toast.makeText(requireContext(), "Coordonnées non numériques", Toast.LENGTH_LONG).show()
            return
        }
        if (lat !in -90.0..90.0 || lng !in -180.0..180.0) {
            Toast.makeText(requireContext(), "Coordonnées hors limites (lat -90..90, lng -180..180)", Toast.LENGTH_LONG).show()
            return
        }
        parentFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, CarteContactFragment.newInstance(editNom.text.toString(), lat, lng))
            .addToBackStack(null)
            .commit()
    }

    companion object {
        private const val ARG_ID = "contact_id"
        private const val KEY_PHOTO = "photo_path"

        // L'_id est passé dans un Bundle (jamais la position dans la liste)
        fun newInstance(id: Long) = DetailContactFragment().apply {
            arguments = Bundle().apply { putLong(ARG_ID, id) }
        }
    }
}