package com.example.contacts.data

// Tous les noms de la table et des colonnes au même endroit
object ContactContract {
    const val TABLE = "contacts"
    const val ID = "_id"
    const val NOM = "nom"
    const val PRENOM = "prenom"
    const val TELEPHONE = "telephone"
    const val EMAIL = "email"
    const val PHOTO_URI = "photo_uri"
    const val LATITUDE = "latitude"
    const val LONGITUDE = "longitude"
}