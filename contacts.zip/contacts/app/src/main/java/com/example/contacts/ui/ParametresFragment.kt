package com.example.contacts.ui

import android.os.Bundle
import androidx.preference.PreferenceFragmentCompat
import com.example.contacts.R

class ParametresFragment : PreferenceFragmentCompat() {

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        // Charge l'écran décrit dans res/xml/preferences.xml
        setPreferencesFromResource(R.xml.preferences, rootKey)
    }
}