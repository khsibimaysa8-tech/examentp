package com.example.contacts.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.contacts.R
import com.example.contacts.data.Contact
import com.example.contacts.data.PreferencesManager
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar

class ListeContactsFragment : Fragment(R.layout.fragment_liste_contacts) {

    // ViewModel partagé avec les autres fragments
    private val viewModel: ContactViewModel by activityViewModels()

    private lateinit var adapter: ContactAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val recycler = view.findViewById<RecyclerView>(R.id.recyclerContacts)
        val editRecherche = view.findViewById<EditText>(R.id.editRecherche)
        val txtVide = view.findViewById<TextView>(R.id.txtVide)
        val fab = view.findViewById<FloatingActionButton>(R.id.fabAjouter)

        adapter = ContactAdapter(
            onClick = { id -> ouvrirDetail(id) },
            onAppeler = { contact -> appeler(contact) }
        )
        recycler.layoutManager = LinearLayoutManager(requireContext())
        recycler.adapter = adapter

        // La liste vient du ViewModel (donc de la base)
        viewModel.contacts.observe(viewLifecycleOwner) { liste ->
            adapter.submitList(liste)
            txtVide.visibility = if (liste.isEmpty()) View.VISIBLE else View.GONE
        }

        // Messages de succès / erreur (ajout, modification, suppression)
        viewModel.message.observe(viewLifecycleOwner) { msg ->
            if (msg != null) {
                Snackbar.make(view, msg, Snackbar.LENGTH_SHORT).show()
                viewModel.messageAffiche()
            }
        }

        // Recherche : le ViewModel relance la requête SQL (LIKE)
        editRecherche.doAfterTextChanged { texte ->
            viewModel.rechercher(texte?.toString() ?: "")
        }

        // Bouton "+" : détail en mode création (id = 0)
        fab.setOnClickListener { ouvrirDetail(0L) }
    }

    // Préférences relues à chaque retour sur la liste -> effet immédiat
    override fun onResume() {
        super.onResume()
        adapter.appliquerPrefs(PreferencesManager.lire(requireContext()))
        viewModel.charger()   // recharge depuis la base (Read à chaque affichage)
    }

    private fun ouvrirDetail(id: Long) {
        parentFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, DetailContactFragment.newInstance(id))
            .addToBackStack(null)
            .commit()
    }

    // ACTION_DIAL : aucune permission nécessaire
    private fun appeler(contact: Contact) {
        if (contact.telephone.isBlank()) {
            Toast.makeText(requireContext(), "Numéro vide", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(contact.telephone)))
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(requireContext(), "Aucune application téléphone", Toast.LENGTH_SHORT).show()
        }
    }
}