package com.example.contacts.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import com.example.contacts.data.ContactContract as C

// Fonctions utilitaires : Contact <-> ContentValues / Cursor
// (toValues() est celle utilisée dans ContactDbHelper)
fun Contact.toValues(): ContentValues = ContentValues().apply {
    put(C.NOM, nom)
    put(C.PRENOM, prenom)
    put(C.TELEPHONE, telephone)
    put(C.EMAIL, email)          // null accepté -> NULL en base
    put(C.PHOTO_URI, photoUri)
    put(C.LATITUDE, latitude)
    put(C.LONGITUDE, longitude)
}

private fun Cursor.toContact(): Contact {
    val iLat = getColumnIndexOrThrow(C.LATITUDE)
    val iLon = getColumnIndexOrThrow(C.LONGITUDE)
    val iEmail = getColumnIndexOrThrow(C.EMAIL)
    val iPhoto = getColumnIndexOrThrow(C.PHOTO_URI)
    return Contact(
        id = getLong(getColumnIndexOrThrow(C.ID)),
        nom = getString(getColumnIndexOrThrow(C.NOM)),
        prenom = getString(getColumnIndexOrThrow(C.PRENOM)),
        telephone = getString(getColumnIndexOrThrow(C.TELEPHONE)),
        email = if (isNull(iEmail)) null else getString(iEmail),
        photoUri = if (isNull(iPhoto)) null else getString(iPhoto),
        // isNull : une position absente reste null (et non 0.0)
        latitude = if (isNull(iLat)) null else getDouble(iLat),
        longitude = if (isNull(iLon)) null else getDouble(iLon)
    )
}

// Seule classe qui contient du SQL
class ContactDao(context: Context) {

    private val helper = ContactDbHelper.getInstance(context)

    // Retourne l'id créé, ou -1 si échec
    fun insert(contact: Contact): Long =
        helper.writableDatabase.insert(C.TABLE, null, contact.toValues())

    // Retourne le nombre de lignes modifiées (0 = contact introuvable)
    fun update(contact: Contact): Int =
        helper.writableDatabase.update(
            C.TABLE, contact.toValues(),
            "${C.ID} = ?", arrayOf(contact.id.toString())
        )

    // Retourne le nombre de lignes supprimées
    fun delete(id: Long): Int =
        helper.writableDatabase.delete(
            C.TABLE, "${C.ID} = ?", arrayOf(id.toString())
        )

    fun getAll(): List<Contact> =
        helper.readableDatabase.query(
            C.TABLE, null, null, null, null, null,
            "${C.NOM} COLLATE NOCASE ASC"
        ).use { cursor ->
            val liste = mutableListOf<Contact>()
            while (cursor.moveToNext()) liste.add(cursor.toContact())
            liste
        }

    fun getById(id: Long): Contact? =
        helper.readableDatabase.query(
            C.TABLE, null, "${C.ID} = ?", arrayOf(id.toString()),
            null, null, null
        ).use { cursor ->
            if (cursor.moveToFirst()) cursor.toContact() else null
        }

    // Recherche en SQL : LIKE sur nom, prénom, téléphone (avec arguments ?)
    fun search(texte: String): List<Contact> {
        val motif = "%$texte%"
        val where = "${C.NOM} LIKE ? OR ${C.PRENOM} LIKE ? OR ${C.TELEPHONE} LIKE ?"
        return helper.readableDatabase.query(
            C.TABLE, null, where, arrayOf(motif, motif, motif),
            null, null, "${C.NOM} COLLATE NOCASE ASC"
        ).use { cursor ->
            val liste = mutableListOf<Contact>()
            while (cursor.moveToNext()) liste.add(cursor.toContact())
            liste
        }
    }
}