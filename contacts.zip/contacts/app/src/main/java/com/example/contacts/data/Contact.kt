package com.example.contacts.data

// Un contact. id = 0 tant qu'il n'est pas enregistré en base.
data class Contact(
    val id: Long = 0,
    val nom: String,
    val prenom: String,
    val telephone: String,
    val email: String? = null,      // ? = peut être vide (null)
    val photoUri: String? = null,   // chemin du fichier photo
    val latitude: Double? = null,
    val longitude: Double? = null
)