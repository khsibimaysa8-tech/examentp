package com.example.contacts.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.contacts.data.ContactContract as C

class ContactDbHelper private constructor(context: Context) :
    SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    // Appelée UNE SEULE FOIS : quand le fichier contacts.db n'existe pas encore
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE ${C.TABLE} (
                ${C.ID}        INTEGER PRIMARY KEY AUTOINCREMENT,
                ${C.NOM}       TEXT NOT NULL,
                ${C.PRENOM}    TEXT NOT NULL,
                ${C.TELEPHONE} TEXT NOT NULL,
                ${C.EMAIL}     TEXT,
                ${C.PHOTO_URI} TEXT,
                ${C.LATITUDE}  REAL,
                ${C.LONGITUDE} REAL
            )
            """
        )
        insererContactsDemo(db)
    }

    // Appelée quand DB_VERSION augmente. Ici (simple) : on supprime et on recrée.
    override fun onUpgrade(db: SQLiteDatabase, ancienne: Int, nouvelle: Int) {
        db.execSQL("DROP TABLE IF EXISTS ${C.TABLE}")
        onCreate(db)
    }

    // 6 contacts de démo (2 sans GPS : latitude/longitude = null)
    private fun insererContactsDemo(db: SQLiteDatabase) {
        val demo = listOf(
            Contact(nom = "Ben Ali", prenom = "Ahmed", telephone = "+216 20 123 456",
                email = "ahmed@mail.com", latitude = 36.8065, longitude = 10.1815),
            Contact(nom = "Trabelsi", prenom = "Sana", telephone = "+216 22 456 789",
                email = "sana@mail.com", latitude = 35.8256, longitude = 10.6084),
            Contact(nom = "Gharbi", prenom = "Youssef", telephone = "+216 50 111 222",
                latitude = 34.7406, longitude = 10.7603),
            Contact(nom = "O'Neil", prenom = "Sarah", telephone = "+216 98 333 444",
                email = "sarah@mail.com"),
            Contact(nom = "Jlassi", prenom = "Mohamed", telephone = "+216 55 777 888"),
            Contact(nom = "Amri", prenom = "Lina", telephone = "+216 29 999 000",
                email = "lina@mail.com", latitude = 36.8625, longitude = 10.1956)
        )
        for (contact in demo) {
            db.insert(C.TABLE, null, contact.toValues())
        }
    }

    companion object {
        private const val DB_NAME = "contacts.db"
        private const val DB_VERSION = 1

        // Singleton : une seule instance pour toute l'application
        @Volatile
        private var instance: ContactDbHelper? = null

        fun getInstance(context: Context): ContactDbHelper {
            // applicationContext = pas de fuite mémoire d'une Activity
            return instance ?: synchronized(this) {
                instance ?: ContactDbHelper(context.applicationContext).also { instance = it }
            }
        }
    }
}