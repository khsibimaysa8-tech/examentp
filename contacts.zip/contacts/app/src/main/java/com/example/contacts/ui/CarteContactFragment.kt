import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import com.example.contacts.R
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class CarteContactFragment : Fragment(R.layout.fragment_carte_contact), OnMapReadyCallback {

    private var nom: String = ""
    private var lat: Double = 0.0
    private var lng: Double = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        nom = requireArguments().getString(ARG_NOM, "")
        lat = requireArguments().getDouble(ARG_LAT)
        lng = requireArguments().getDouble(ARG_LNG)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        (childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment)
            .getMapAsync(this)
    }

    override fun onMapReady(map: GoogleMap) {
        val pos = LatLng(lat, lng)
        map.addMarker(MarkerOptions().position(pos).title(nom))
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(pos, 15f))
    }

    companion object {
        private const val ARG_NOM = "nom"
        private const val ARG_LAT = "lat"
        private const val ARG_LNG = "lng"

        fun newInstance(nom: String, lat: Double, lng: Double) =
            CarteContactFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_NOM, nom)
                    putDouble(ARG_LAT, lat)
                    putDouble(ARG_LNG, lng)
                }
            }
    }
}