package com.example.contacts.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.contacts.data.Contact
import com.example.contacts.data.ContactDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ViewModel partagé : liste + détail + formulaire utilisent la même instance
class ContactViewModel(app: Application) : AndroidViewModel(app) {

    private val dao = ContactDao(app)

    private val _contacts = MutableLiveData<List<Contact>>(emptyList())
    val contacts: LiveData<List<Contact>> = _contacts

    // Message à afficher (Snackbar/Toast) : succès ou erreur
    private val _message = MutableLiveData<String?>()
    val message: LiveData<String?> = _message

    // Texte de recherche courant (gardé pour recharger après chaque modification)
    private var filtre: String = ""

    init {
        charger()
    }

    // Recharge la liste (avec ou sans filtre), hors du thread principal
    fun charger() {
        viewModelScope.launch {
            val liste = withContext(Dispatchers.IO) {
                if (filtre.isBlank()) dao.getAll() else dao.search(filtre.trim())
            }
            _contacts.value = liste
        }
    }

    fun rechercher(texte: String) {
        filtre = texte
        charger()
    }

    // Lecture d'un contact (pour l'écran détail / modification)
    suspend fun getContact(id: Long): Contact? =
        withContext(Dispatchers.IO) { dao.getById(id) }

    fun ajouter(contact: Contact) {
        viewModelScope.launch {
            val id = withContext(Dispatchers.IO) { dao.insert(contact) }
            _message.value =
                if (id == -1L) "Échec de l'ajout du contact" else "Contact ajouté"
            charger()
        }
    }

    fun modifier(contact: Contact) {
        viewModelScope.launch {
            val n = withContext(Dispatchers.IO) { dao.update(contact) }
            _message.value =
                if (n == 0) "Contact introuvable" else "Contact modifié"
            charger()
        }
    }

    fun supprimer(id: Long) {
        viewModelScope.launch {
            val n = withContext(Dispatchers.IO) { dao.delete(id) }
            _message.value =
                if (n == 0) "Contact introuvable" else "Contact supprimé"
            charger()
        }
    }

    // Appelé après affichage du message, pour ne pas le réafficher (rotation)
    fun messageAffiche() {
        _message.value = null
    }
}