package com.example.contacts.data

import android.content.Context
import android.graphics.Color
import androidx.preference.PreferenceManager

// Valeurs déjà converties, prêtes pour l'adapter et le détail
data class AffichagePrefs(
    val tailleSp: Float,
    val couleur: Int,
    val appelActif: Boolean
)

// Seul endroit qui lit les préférences
object PreferencesManager {

    const val KEY_TAILLE = "taille_police"
    const val KEY_COULEUR = "couleur_preferee"
    const val KEY_APPEL = "appel_depuis_liste"

    fun lire(context: Context): AffichagePrefs {
        val prefs = PreferenceManager.getDefaultSharedPreferences(context)

        val taille = prefs.getString(KEY_TAILLE, "16")?.toFloatOrNull() ?: 16f

        val couleur = try {
            Color.parseColor(prefs.getString(KEY_COULEUR, "#000000"))
        } catch (e: IllegalArgumentException) {
            Color.BLACK   // valeur invalide -> noir par défaut
        }

        val appel = prefs.getBoolean(KEY_APPEL, false)

        return AffichagePrefs(taille, couleur, appel)
    }
}