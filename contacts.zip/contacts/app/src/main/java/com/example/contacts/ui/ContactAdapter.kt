package com.example.contacts.ui

import android.net.Uri
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.contacts.R
import com.example.contacts.data.AffichagePrefs
import com.example.contacts.data.Contact
import java.io.File

class ContactAdapter(
    private val onClick: (Long) -> Unit,        // reçoit l'_id (pas la position)
    private val onAppeler: (Contact) -> Unit
) : ListAdapter<Contact, ContactAdapter.VH>(Diff) {

    // Préférences déjà converties (taille, couleur, appel)
    private var prefs = AffichagePrefs(16f, 0xFF000000.toInt(), false)

    fun appliquerPrefs(nouvelles: AffichagePrefs) {
        prefs = nouvelles
        notifyDataSetChanged()   // rafraîchit toutes les lignes
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val photo: ImageView = v.findViewById(R.id.imgPhoto)
        val nom: TextView = v.findViewById(R.id.txtNomComplet)
        val tel: TextView = v.findViewById(R.id.txtTelephone)
        val btnAppeler: ImageButton = v.findViewById(R.id.btnAppeler)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_contact, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val c = getItem(position)

        h.nom.text = "${c.prenom} ${c.nom}"
        h.tel.text = c.telephone

        // Préférences : taille (sp) + couleur du nom/prénom
        h.nom.setTextSize(TypedValue.COMPLEX_UNIT_SP, prefs.tailleSp)
        h.tel.setTextSize(TypedValue.COMPLEX_UNIT_SP, prefs.tailleSp)
        h.nom.setTextColor(prefs.couleur)

        // Photo : chemin du fichier dans filesDir, sinon icône par défaut
        if (c.photoUri != null) {
            h.photo.setImageURI(Uri.fromFile(File(c.photoUri)))
        } else {
            h.photo.setImageResource(android.R.drawable.ic_menu_gallery)
        }

        // Bouton Appeler visible seulement si la préférence est activée
        h.btnAppeler.visibility = if (prefs.appelActif) View.VISIBLE else View.GONE
        h.btnAppeler.setOnClickListener { onAppeler(c) }  // n'ouvre pas le détail

        h.itemView.setOnClickListener { onClick(c.id) }
    }

    object Diff : DiffUtil.ItemCallback<Contact>() {
        override fun areItemsTheSame(a: Contact, b: Contact) = a.id == b.id
        override fun areContentsTheSame(a: Contact, b: Contact) = a == b
    }
}