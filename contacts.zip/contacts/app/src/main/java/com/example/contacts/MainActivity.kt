package com.example.contacts

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import com.example.contacts.ui.ListeContactsFragment
import com.example.contacts.ui.ParametresFragment

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById(R.id.toolbar))

        // Seulement au 1er lancement (après rotation, Android restaure le fragment)
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, ListeContactsFragment())
                .commit()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_parametres) {
            // Évite d'empiler plusieurs écrans Paramètres
            val actuel = supportFragmentManager.findFragmentById(R.id.fragment_container)
            if (actuel !is ParametresFragment) {
                supportFragmentManager.beginTransaction()
                    .replace(R.id.fragment_container, ParametresFragment())
                    .addToBackStack(null)
                    .commit()
            }
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}